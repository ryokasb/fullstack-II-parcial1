const buscador = document.getElementById("buscador");
const btnBuscar = document.getElementById("btn-buscar");
const librosContainer = document.getElementById("mas-vendidos");

// Convertir NodeList a Array para filtrar
const libros = Array.from(librosContainer.getElementsByClassName("libro-card"));

// Función para filtrar libros
function filtrarLibros() {
    const termino = buscador.value.toLowerCase();

    libros.forEach(libro => {
        const titulo = libro.querySelector("h3").textContent.toLowerCase();
        const autor = libro.querySelector("p") ? libro.querySelector("p").textContent.toLowerCase() : "";

        if (titulo.includes(termino) || autor.includes(termino)) {
            libro.style.display = "block";
        } else {
            libro.style.display = "none";
        }
    });
}

// Filtrar al escribir
buscador.addEventListener("input", filtrarLibros);

// Filtrar al hacer click en el botón
btnBuscar.addEventListener("click", filtrarLibros);