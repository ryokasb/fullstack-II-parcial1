
// Validaciones simples para formularios
document.addEventListener("DOMContentLoaded", () => {
  const forms = document.querySelectorAll("form");

  forms.forEach(form => {
    form.addEventListener("submit", e => {
      let valido = true;
      const inputs = form.querySelectorAll("input[required], textarea[required]");

      inputs.forEach(input => {
        if (!input.value.trim()) {
          valido = false;
          input.style.border = "2px solid red";
          input.placeholder = "Este campo es obligatorio";
        } else {
          input.style.border = "1px solid #ccc";
        }
      });

      if (!valido) {
        e.preventDefault();
        alert("Por favor, completa todos los campos obligatorios.");
      }
    });
  });
});