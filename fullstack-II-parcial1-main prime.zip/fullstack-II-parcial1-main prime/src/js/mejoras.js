
// Pequeñas mejoras de interactividad
document.addEventListener("DOMContentLoaded", () => {
  const botones = document.querySelectorAll("button");

  botones.forEach(boton => {
    boton.addEventListener("mouseover", () => {
      boton.style.backgroundColor = "#444";
      boton.style.color = "#fff";
    });
    boton.addEventListener("mouseout", () => {
      boton.style.backgroundColor = "";
      boton.style.color = "";
    });
  });
});